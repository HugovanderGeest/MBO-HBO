# MBO-HBO

GITHUB voor de opdracht MBO-HBO 

Mbombo is een Groeps project met 2 MediaDeveloper en 2 web designers, deze website is gemaak voor een opdrachtgever van een college zij willen de website van mbo en hbo een nieuw leven in blazen, de oude website was gemaakt in 2013 en dus aan de oude kant, wij hebben opnieuw naar de website gekeken en onderscheid gehouden tussen wat wegdoet en wat moet blijven, met die inzicht hebben wij onderzocht wat het meest gebruik werd en wat er opnieuw moet gebruikt Moest worden, onze zicht was om de website zo overzichtelijk mogelijk te maken en daar de gebruiker de mogelijk geven om zijn mening te posten..

live link: http://25383.hosts1.ma-cloud.nl/IDP/MBO-HBO/index.html
